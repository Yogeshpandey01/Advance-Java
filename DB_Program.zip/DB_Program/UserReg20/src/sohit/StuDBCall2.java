package sohit;
import java.util.*;
import java.sql.*;
public class StuDBCall2 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the roNo:");
		long roNo=Long.parseLong(s.nextLine());
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
		PreparedStatement ps=con.prepareStatement("select * from stuDetails20 where roNo=?");

	}

}
