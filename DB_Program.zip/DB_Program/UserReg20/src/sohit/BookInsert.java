
package sohit;
import java.util.*;
import java.sql.*;
public class BookInsert {
	public static void main(String[] args) throws ClassNotFoundException,
	SQLException{
	Scanner s=new Scanner(System.in);
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("insert into Book20 values (?,?,?,?,?)");
    System.out.println("Enter the Numberof product:");
    int n=Integer.parseInt(s.nextLine());
    for(int i=1;i<=n;i++)
    {
    	System.out.println("Enter the bCode:");
    	String bCode=s.nextLine();
    	System.out.println("Enter the bName:");
    	String bName=s.nextLine();
    	System.out.println("Enter the bAuthor:");
    	String bAuthor=s.nextLine();
    	System.out.println("Enter the bPrice:");
    	float bPrice=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the bQty:");
    	int bQty=Integer.parseInt(s.nextLine());
    	ps.setString(1,bCode);
    	ps.setString(2, bName);
    	ps.setString(3, bAuthor);
    	ps.setFloat(4, bPrice);
    	ps.setInt(5,bQty);
    	int k=ps.executeUpdate();
    	if(k>0)
    	{
    		System.out.println("Product Inserted");
    	}
    } //end of for loop
       con.close();
       s.close();
	}

}
