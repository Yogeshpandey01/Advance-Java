package sohit;
import java.util.*;
import java.sql.*;
public class DBProcCallAssignment {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Uname:");
	String Uname=s.nextLine();
	System.out.println("Enter the Pword:");
	String Pword=s.nextLine();
	System.out.println("Enter the Fname:");
	String Fname=s.nextLine();
	System.out.println("Enter the Lname:");
	String Lname=s.nextLine();
	System.out.println("Enter the Age:");
	int Age=Integer.parseInt(s.nextLine());
	System.out.println("Enter the Addr:");
	String Addr=s.nextLine();
	System.out.println("Enter the Phno:");
	long Phno=Long.parseLong(s.nextLine());
	System.out.println("Enter the Email:");
	String Email=s.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	CallableStatement cs=con.prepareCall("{call Update25(?,?,?,?,?,?,?,?)}");
	cs.setString(1, Uname);
	cs.setString(2,Pword);
	cs.setString(3, Fname);
	cs.setString(4, Lname);
	cs.setInt(5, Age);
	cs.setString(6,Addr);
	cs.setLong(7,Phno);
	cs.setString(8,Email);
	cs.execute();
	System.out.println("Procedure Executed..!!");
	con.close();
	s.close();
	}

}
