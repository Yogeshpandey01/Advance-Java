package sohit;
import java.util.*;
import java.sql.*;
public class BookDelete{

	public static void main(String[] args) throws ClassNotFoundException
	,SQLException{
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the bCode:");
		String bCode=s.nextLine();
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    Connection con=DriverManager.getConnection
	    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	    PreparedStatement ps1=con.prepareStatement
	    		("Select *from Book20 where bCode=?");
	    ps1.setString(1, bCode);
	    ResultSet rs=ps1.executeQuery();
	    if(rs.next())
	    {
	    	
	    	PreparedStatement ps2=con.prepareStatement
	        		("Delete Book20 where bCode=?");
	    	ps2.setString(1, bCode);
	    	int k=ps2.executeUpdate();
	    	if(k>0) {
	    		System.out.println("Product is Deleted..!!");
	    	    }	
	    	}
	    else {
	    	System.out.println("Invalid pCode..!!");
	    }
	     con.close();
	     s.close();

		

	}

}
