package sohit;
import java.util.*;
import java.sql.*;
public class StuDBCall {
     
	public static void main(String[] args) throws ClassNotFoundException ,SQLException{
		String result;
	Scanner s=new Scanner(System.in);
	System.out.print("Enter the roNo:");
	long roNo=Long.parseLong(s.nextLine());
	System.out.print("Enter the stuName:");
	String stuName=s.nextLine();
	System.out.print("Enter the branch:");
	String branch=s.nextLine();
	System.out.print("ENter the phNo:");
	long phNo=Long.parseLong(s.nextLine());
	System.out.print("Enter the mailId:");
	String mailId=s.nextLine();
	System.out.print("Enter the city:");
	String city=s.nextLine();
	System.out.print("Enter the state:");
	String state=s.nextLine();
	System.out.print("Enter the pCode:");
	long pCode=Long.parseLong(s.nextLine());
	System.out.println("Enter the Marks in sub1:");
	float sub1=Float.parseFloat(s.nextLine());
	System.out.println("Enter the Marks in sub2:");
	float sub2=Float.parseFloat(s.nextLine());
	System.out.println("Enter the Marks in sub3:");
	float sub3=Float.parseFloat(s.nextLine());
	System.out.println("Enter the Marks in sub4:");
	float sub4=Float.parseFloat(s.nextLine());
	System.out.println("Enter the Marks in sub5:");
	float sub5=Float.parseFloat(s.nextLine());
	System.out.println("Enter the Marks in sub6:");
	float sub6=Float.parseFloat(s.nextLine());
	double totMark=(sub1+sub2+sub3+sub4+sub5+sub6);
	double per=((totMark/6));
	
	if(per>=70 && per<=100) {
		result="Destntion";
	}
	else if(per>=60 && per<70) {
		result="Frist Class";
	}
	else if(per>=50 && per<60) {
		result="Second Class";
	}
	else if (per>=35 && per<50) {
		result="Third Class";
		
	}
	else {
		result="failed";
	}
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	CallableStatement cs=con.prepareCall("{call studentDetails20(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
	cs.setLong(1,roNo);
	cs.setString(2, stuName);
	cs.setString(3, branch);
	cs.setLong(4, phNo);
	cs.setString(5, mailId);
	cs.setString(6, city);
	cs.setString(7, state);
	cs.setLong(8, pCode);
	cs.setFloat(9,sub1);
	cs.setFloat(10,sub2);
	cs.setFloat(11,sub3);
	cs.setFloat(12,sub4);
	cs.setFloat(13,sub5);
	cs.setFloat(14,sub6);
	cs.setDouble(15, totMark);
	cs.setDouble(16, per);
	cs.setString(17,result);
	cs.execute();
	System.out.println("Procedure Executed..!!");
	con.close();
	s.close();
	
	}

}
