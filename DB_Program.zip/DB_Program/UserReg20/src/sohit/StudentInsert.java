package sohit;
import java.util.*;
import java.sql.*;
public class StudentInsert {
	public static void main(String[] args) throws ClassNotFoundException,
	SQLException{
	Scanner s=new Scanner(System.in);
	String result;
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("insert into stu20 values (?,?,?,?,?,?,?,?,?,?,?,?)");
    System.out.println("Enter the Number of Student:");
    int n=Integer.parseInt(s.nextLine());
    for(int i=1;i<=n;i++)
    {
    	System.out.println("Enter the rNo:");
    	String rNo=s.nextLine();
    	System.out.println("Enter the sName:");
    	String sName=s.nextLine();
    	System.out.println("Enter the sBranch:");
    	String sBranch=s.nextLine();
    	System.out.println("Enter the Marks in sub1:");
    	float sub1=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the Marks in sub2:");
    	float sub2=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the Marks in sub3:");
    	float sub3=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the Marks in sub4:");
    	float sub4=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the Marks in sub5:");
    	float sub5=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the Marks in sub6:");
    	float sub6=Float.parseFloat(s.nextLine());
    	double totMark=(sub1+sub2+sub3+sub4+sub5+sub6);
    	double per=((totMark/6));
    	
    	if(per>=70 && per<=100) {
    		result="Destntion";
    	}
    	else if(per>=60 && per<70) {
    		result="Frist Class";
    	}
    	else if(per>=50 && per<60) {
    		result="Second Class";
    	}
    	else if (per>=35 && per<50) {
    		result="Third Class";
    		
    	}
    	else {
    		result="failed";
    	}
    	
    	ps.setString(1,rNo);
    	ps.setString(2, sName);
    	ps.setString(3, sBranch);
    	ps.setFloat(4,sub1);
    	ps.setFloat(5,sub2);
    	ps.setFloat(6,sub3);
    	ps.setFloat(7,sub4);
    	ps.setFloat(8,sub5);
    	ps.setFloat(9,sub6);
    	ps.setDouble(10, totMark);
    	ps.setDouble(11, per);
    	ps.setString(12,result);
    	int k=ps.executeUpdate();
    	if(k>0)
    	{
    		System.out.println("Product Inserted");
    	}
    } //end of for loop
       con.close();
       s.close();
	}

}
