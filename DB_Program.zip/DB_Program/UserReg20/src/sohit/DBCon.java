package sohit;
import java.util.*;
import java.sql.*;
public class DBCon {
 public static void main(String[] args) throws ClassNotFoundException,SQLException {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the UName:");
	String UName=s.nextLine();
	System.out.println("Enter the pWord:");
	String pWord=s.nextLine();
	System.out.println("Enter the FName:");
	String FName=s.nextLine();
	System.out.println("Enter the LName:");
	String LName=s.nextLine();
	System.out.println("Enter the addr:");
	String addr=s.nextLine();
	System.out.println("Enter the PhNo:");
	Long PhNo= Long.parseLong(s.nextLine());
	System.out.println("Enter the mId:");
	String mId=s.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	PreparedStatement ps=con.prepareStatement("insert into UserReg20 values(?,?,?,?,?,?,?)");
	ps.setString(1, UName);
	ps.setString(2, pWord);
	ps.setString(3, FName);
	ps.setString(4, LName);
	ps.setString(5, addr);
	ps.setLong(6, PhNo);
	ps.setString(7, mId);
	int k=ps.executeUpdate();
	if(k>0)
	{
		System.out.println("successfully");
	
	}
	con.close();
	s.close();
	}

}

