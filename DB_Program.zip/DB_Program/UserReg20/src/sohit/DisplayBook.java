package sohit;
import java.util.*;
import java.sql.*;
public class DisplayBook {

	public static void main(String[] args) 
	throws ClassNotFoundException,SQLException{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the bCode:");
		String bCode=s.nextLine();
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
		PreparedStatement ps=con.prepareStatement
	    		("Select * from Book20 where bCode=? ");
	    ps.setString(1, bCode);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			System.out.println(rs.getString(2)+"\t"+
		rs.getString(3)+"\t"+rs.getFloat(4)+"\t"+rs.getInt(5));
		}
	con.close();
	}
}