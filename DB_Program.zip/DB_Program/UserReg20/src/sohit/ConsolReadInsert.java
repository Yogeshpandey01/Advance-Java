package sohit;
import java.util.*;
import java.sql.*;
public class ConsolReadInsert {
	public static void main(String[] args) throws ClassNotFoundException,
	SQLException{
	Scanner s=new Scanner(System.in);
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("insert into Emp20 values (?,?,?,?,?,?)");
    System.out.println("Enter the Number of Employee:");
    int n=Integer.parseInt(s.nextLine());
    for(int i=1;i<=n;i++)
    {
    	System.out.println("Enter the eId:");
    	String eId=s.nextLine();
    	System.out.println("Enter the eName:");
    	String eName=s.nextLine();
    	System.out.println("Enter the eDesg:");
    	String eDesg=s.nextLine();
    	System.out.println("Enter the eAge:");
    	int eAge=Integer.parseInt(s.nextLine());
    	System.out.println("Enter the bSal");
    	float bSal=Float.parseFloat(s.nextLine());
    	double totSal= (bSal+0.98*bSal+0.67*bSal);
    	ps.setString(1,eId);
    	ps.setString(2, eName);
    	ps.setString(3, eDesg);
    	ps.setInt(4,eAge);
    	ps.setFloat(5, bSal);
    	ps.setDouble(6, totSal);
    	int k=ps.executeUpdate();
    	if(k>0)
    	{
    		System.out.println("Product Inserted");
    	}
    } //end of for loop
       con.close();
       s.close();
	}

}
