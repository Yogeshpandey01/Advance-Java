package test;
import java.util.*;
import java.io.*;
import java.sql.*;
public class DBCon13 {

	public static void main(String[] args)  throws ClassNotFoundException,SQLException,IOException{
	Scanner s =new Scanner(System.in);
	System.out.println("Enter the id:");
	String id=s.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("select * from TextTab20 where Id=?");
    ps.setString(1, id);
    ResultSet rs=ps.executeQuery();
    if(rs.next()) {
    	System.out.println("Enter the FPath & FName(destination)");
    	File f=new File(s.nextLine());
    	FileWriter fw=new FileWriter(f);
    	Clob c=rs.getClob(2);
    	Reader r=c.getCharacterStream();
    	int ch;
    	while((ch=r.read())!=-1) {
    	fw.write(ch);
    	
    	}
    	System.out.println("File Retrived successfully");
    	fw.close();
    } else {
    	System.out.println("Invalid Id");
    }
   con.close();
   s.close();
	}

}
