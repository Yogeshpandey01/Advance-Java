package test;
import java.util.*;
import java.sql.*;
public class ConnectionPoolManager
{
	String databaseUrl="jdbc:oracle:thin:@localhost:1521:orcl";
	String userName="scott";
	String password="tiger";
	@SuppressWarnings("rawtypes")
	Vector pool=new Vector();
	public ConnectionPoolManager()
	{
		initialize();
	}
	private void initialize() 
	{
		initializeConnectionPool();
		// TODO Auto-generated method stub
		
	}
	
	@SuppressWarnings("unchecked")
	private void initializeConnectionPool() 
	{
		while(!checkIfConnectionPoolIsFull()) 
		{
			System.out.println("Connection pool is not Full.....");
			pool.addElement(createNewconnectionforPool());
		}
		System.out.println("connection pool is Full..");
		}
	private synchronized boolean checkIfConnectionPoolIsFull()
	{
		final int MAX_POOL_SIZE=5;
		if(pool.size()<MAX_POOL_SIZE) 
		{
			return false; 
			}
		return true; 
		}
	private Connection
					createNewconnectionforPool()
	{
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(databaseUrl,userName,password);
			System.out.println("Connection:"+con);
		}
		catch (SQLException sqle) {
			System.err.println("SQLException:"+sqle);
			return null;
		}
			catch(ClassNotFoundException cnfe) {
				System.err.println("ClassNotFoundException.."+cnfe);
				return null;
			}
			return con;
			}
		public synchronized Connection
		getConnectionfromPool() 
		{
			Connection con=null; 
			if(pool.size()>0) 
			{
				con=(Connection)pool.firstElement();
				pool.removeElementAt(0);
			}
				return con;
			}
			@SuppressWarnings("unchecked")
			public synchronized
			void returnConnectionToPool (Connection con) 
			{
				pool.addElement(con);
			}
			public static void main(String[]args)
				throws SQLException
			{
				ConnectionPoolManager cpm=new ConnectionPoolManager();
				Connection con=cpm.getConnectionfromPool();
				PreparedStatement ps=con.prepareStatement("select * from sellproduct20");
				System.out.println("Dis using con:"+con);
				System.out.println("size of ConnectionPool:"+cpm.pool.size());
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t"+rs.getInt(4));
					cpm.returnConnectionToPool(con);
					System.out.println("Size of connection pool:"+cpm.pool.size());
					
				}
			}
		}