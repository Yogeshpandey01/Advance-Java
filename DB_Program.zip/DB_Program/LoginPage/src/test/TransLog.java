package test;
import java.io.*;
import java.util.*;
public final class TransLog implements Serializable{
	private final double tId;
	private final long bAccNo;
	private final int amt;
	private final Date d;
    public TransLog(double tId,long bAccNo,int amt,Date d) {
		this.tId=tId;
		this.bAccNo=bAccNo;
		this.amt=amt;
		this.d=d;
    }
		public final String toString(){
			return ("tId:"+tId+"\n bAccNo"+bAccNo+"\n amt"+amt+"\n date"+d);
		}
	}

	


