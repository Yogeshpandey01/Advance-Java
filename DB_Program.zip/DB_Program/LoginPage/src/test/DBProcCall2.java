package test;
import java.util.*;
import java.sql.*;
public class DBProcCall2 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the accNo:");
	long accNo=Long.parseLong(s.nextLine());
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	PreparedStatement ps=con.prepareStatement("select * from Bank21 where accNo=?");
	ps.setLong(1, accNo);
	ResultSet rs=ps.executeQuery();
	if(rs.next()) {
		CallableStatement cs=con.prepareCall("{call RetriveAccontDetails21(?,?,?,?,?,?)}");
		cs.setLong(1, accNo);
		cs.registerOutParameter(2,Types.VARCHAR);
		cs.registerOutParameter(3, Types.FLOAT);
		cs.registerOutParameter(4, Types.VARCHAR);
		cs.registerOutParameter(5, Types.VARCHAR);
		cs.registerOutParameter(6, Types.BIGINT);
		cs.execute();
		System.out.println("CustName:"+cs.getString(2));
		System.out.println("Bal:"+cs.getFloat(3));
		System.out.println("AccType:"+cs.getString(4));
		System.out.println("Address:"+cs.getString(5));
		System.out.println("PhoneNo:"+cs.getLong(6));
		
	}else {
		System.out.println("Invalid Account NUmber");
	}
	con.close();
	s.close();

	}

}
