package test;
import java.sql.*;
public class BatchProc2 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
		PreparedStatement ps=con.prepareStatement("insert into sellproduct20 values(?,?,?,?)");
		ps.setString(1, "A999");
		ps.setString(2, "samosha");
		ps.setFloat(3,10F);
		ps.setInt(4, 5);
        ps.addBatch();		
        ps.setString(1, "A777");
		ps.setString(2, "Dhosa");
		ps.setFloat(3,100F);
		ps.setInt(4, 10);
        ps.addBatch();	
        int k[]=ps.executeBatch();
        for(int i:k) {
        	System.out.print("Record Inserted..!!");
        }
		
		con.close();

	}

}
