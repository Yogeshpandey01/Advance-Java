package test;
import java.util.*;
import java.sql.*;
public class DBCon5 {
	public static void main(String[] args) throws ClassNotFoundException,
	SQLException{
	Scanner s=new Scanner(System.in);
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("insert into sellproduct20 values (?,?,?,?)");
    System.out.println("Enter the Numberof product:");
    int n=Integer.parseInt(s.nextLine());
    for(int i=1;i<=n;i++)
    {
    	System.out.println("Enter the pCode:");
    	String pCode=s.nextLine();
    	System.out.println("Enter the pName:");
    	String pName=s.nextLine();
    	System.out.println("Enter the pPrice:");
    	float pPrice=Float.parseFloat(s.nextLine());
    	System.out.println("Enter the pQty:");
    	int pQty=Integer.parseInt(s.nextLine());
    	ps.setString(1,pCode);
    	ps.setString(2, pName);
    	ps.setFloat(3, pPrice);
    	ps.setInt(4,pQty);
    	int k=ps.executeUpdate();
    	if(k>0)
    	{
    		System.out.println("Product Inserted");
    	}
    } //end of for loop
       con.close();
       s.close();
	}

}
