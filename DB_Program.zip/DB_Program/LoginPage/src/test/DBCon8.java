package test;
import java.util.*;
import java.sql.*;
import java.io.*;

public class DBCon8 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException,IOException {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the id:");
	String id=s.nextLine();
	System.out.println("Enter the FPath and FName (source)");
	File f =new File(s.nextLine());
	FileInputStream fis=new FileInputStream(f);
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("insert into MFTabs20 values (?,?)");
    ps.setString(1, id);
    ps.setBinaryStream(2, fis,(int)f.length());
    int k=ps.executeUpdate();
    if(k>0) {
    	System.out.println("File store successfully..!!");
    	
    }
    con.close();
    s.close();
	
	}

}
