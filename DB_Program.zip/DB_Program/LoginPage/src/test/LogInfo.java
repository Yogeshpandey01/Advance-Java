package test;
import java.util.*;
import java.sql.*;
public class LogInfo {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{	
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the UName:");
	String UName=s.nextLine();
	System.out.println("Enter the pWord:");
	String pWord=s.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	PreparedStatement ps = con.prepareStatement("select * From LoginPage20 where UName=? and pWord=?");
	ps.setString(1, UName);
	ps.setString(2, pWord);
	ResultSet rs=ps.executeQuery();
	if(rs.next())
	{
		System.out.println("Login Successfully..!!");
		System.out.println("WELCOME"+rs.getString(1));
	}
	else {
		System.out.println("Invalid UserName or Password" );
     }
	con.close();
	s.close();
	}

}
