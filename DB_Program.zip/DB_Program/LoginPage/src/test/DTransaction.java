package test;
import java.util.*;
import java .sql.*;
public class DTransaction {

	public static void main(String[] args) throws ClassNotFoundException,SQLException{
		Scanner s=new Scanner(System.in);
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
		PreparedStatement ps=con.prepareStatement("Update Bank21 set bal=bal+? where accno=?");
		PreparedStatement ps1=con.prepareStatement("select * from Bank21 where accno=?");
		con.setAutoCommit(false);//step1
		Savepoint s1=con.setSavepoint();//step2
		System.out.println("Enter the accNo(Home):");
		long accNo1=Long.parseLong(s.nextLine());
		ps1.setLong(1, accNo1);
		ResultSet rs1=ps1.executeQuery();
		if(rs1.next()) {
			float bal=rs1.getFloat(3);
			System.out.print("Enter the bAccNo(Benificery):");
			long bAccNo=Long.parseLong(s.nextLine());
			ps1.setLong(1, bAccNo);
			ResultSet rs2=ps1.executeQuery();
			if(rs2.next()) {
				System.out.print("Enter the amt(Amount) to be Transaction");
				float amt=Float.parseFloat(s.nextLine());
				if(amt<=bal) {
					ps.setFloat(1, -amt);
					ps.setLong(2, accNo1);
					int i=ps.executeUpdate();
					ps.setFloat(1, amt);
					ps.setLong(2, bAccNo);
					int j=ps.executeUpdate();
					if(i==1 && j==1) {
						System.out.print("Transaction Complete..!!");
						con.commit();
					}//end of if
					else {
						System.out.print("Transaction Failed..!!");
						con.rollback(s1);
					}
					
					
				}//end of if
				else {
					System.out.print("Insufficient Funds..!!");
					
				}

					
				}//end of if
			else {
				
				System.out.println("Invalid bAccNo..!!");
				
				
			}
		} //end of if
		else {
			
			System.out.println("Invalid bAccNo(Home)..!!");
		}
		
		
		con.close();
		s.close();

	}
	

}
