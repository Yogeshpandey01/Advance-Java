package test;
import java.util.*;
import java.sql.*;
public class DBProcCall {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the accNo:");
	long accNo=Long.parseLong(s.nextLine());
	System.out.println("Enter custName:");
	String custName=s.nextLine();
	System.out.println("Enter the bal:");
	float bal=Float.parseFloat(s.nextLine());
	System.out.println("Enter the accType(saving / current)");
	String accType=s.nextLine();
	System.out.println("Enter the addr:");
	String addr=s.nextLine();
	System.out.println("Enter the phNo:");
	long phNo=Long.parseLong(s.nextLine());
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	CallableStatement cs=con.prepareCall("{call CreateAccontDetails21(?,?,?,?,?,?)}");
	cs.setLong(1, accNo);
	cs.setString(2, custName);
	cs.setFloat(3, bal);
	cs.setString(4, accType);
	cs.setString(5, addr);
	cs.setLong(6, phNo);
	cs.execute();
System.out.println("Procedure Executed..!!");
con.close();
s.close();
	}

}
