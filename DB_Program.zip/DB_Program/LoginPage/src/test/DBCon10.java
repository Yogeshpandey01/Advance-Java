package test;
import java.util.*;
import java.io.*;
import java.sql.*;
import java.sql.Date;
public class DBCon10 {

	public static void main(String[] args)  throws ClassNotFoundException ,SQLException,IOException{
		
    Scanner s=new Scanner(System.in);
    System.out.print("Enter the Id");
    String Id=s.nextLine();
    File f=new File("E:\\images\\objstore.txt");
    TransLog ob1=new TransLog(Math.random(),6123456L,12000,new java.util.Date());
    FileOutputStream fos=new FileOutputStream(f);
    ObjectOutputStream oos=new ObjectOutputStream(fos);
    oos.writeObject(ob1);//serialization
    oos.close();
    FileInputStream fis= new FileInputStream(f);
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("insert into ObjTab20 values(?,?)");
    ps.setString(1, Id);
    ps.setBinaryStream(2,fis, (int)f.length());
    int k= ps.executeUpdate() ;
    if(k>0)
    {
    	System.out.println("Object stored successfully");
    }
    con.close();
    f.delete();
    s.close();
	}

}
