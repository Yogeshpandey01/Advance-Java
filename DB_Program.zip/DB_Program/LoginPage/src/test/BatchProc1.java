package test;
import java.sql.*;
public class BatchProc1 {

	public static void main(String[] args)  throws ClassNotFoundException,SQLException{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	Statement stm=con.createStatement();
	stm.addBatch("insert into Bank21 values(123456789,'sohit',2000,'current')");
	stm.addBatch("insert into custDetails21 values(123456789,'Dhelhi',987865434)");
	int k[] =stm.executeBatch();
	for(int i:k) {
		System.out.println("Record inserted..!!");
		con.close();
	}

	}

}
