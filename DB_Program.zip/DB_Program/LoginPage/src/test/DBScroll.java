package test;
import java.sql.*;
public class DBScroll {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");	
	    Statement stm=con.createStatement(1004,1007);
	    ResultSet rs=stm.executeQuery("select * from sellproduct20");
	    rs.afterLast();
	    System.out.println("--Display record in reverse--");
	    while(rs.previous()) {
	    	 System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getFloat(3)+"\t"+rs.getInt(4));
	    	 
	    }//loop end
	    PreparedStatement ps=con.prepareStatement("select * from sellproduct20",1004,1007);
	    ResultSet rs1=ps.executeQuery();
	    rs1.absolute(3);
	    System.out.println("--Display Third Record--");
	    System.out.println(rs1.getString(1)+"\t"+rs1.getString(2)+"\t"+rs1.getFloat(3)+"\t"+rs1.getInt(4));
	    con.close();
	    

	}

}
