package test;
import java.util.*;
import java.io.*;
import java.sql.*;
public class DBCon11 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException,IOException {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Id:");
		String Id=s.nextLine();
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    Connection con=DriverManager.getConnection
	    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	    PreparedStatement ps=con.prepareStatement
	    		("select * from ObjTab20 where Id=?");
	    ps.setString(1, Id);
	    ResultSet rs=ps.executeQuery();
	    if(rs.next()) {
	    	File f=new File("E:\\images\\objRetrive.txt");
	    	FileOutputStream fos=new FileOutputStream(f);
	    	Blob b=rs.getBlob(2);
	    	byte by[] = b.getBytes(1, (int)b.length());
	    	fos.write(by);
	    	fos.close();
	    	FileInputStream fis= new FileInputStream(f);
	    	ObjectInputStream ois=new ObjectInputStream(fis);
	    	TransLog ob2=(TransLog)ois.readObject();
	    	System.out.println("--Log Details--");
	    	System.out.println(ob2);
	    	ois.close();
	    	f.delete();
	    	
	    }else {
	    	System.out.println("Invalid Id");
	    }
          con.close();
          s.close();
	}

}
