package test;
import java.util.*;
import java.sql.*;
import java.io.*;

public class DBCon9 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException,IOException {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the id:");
	String id=s.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps=con.prepareStatement
    		("select * from  MFTabs20 id=?");
    ps.setString(1, id);
   ResultSet rs=ps.executeQuery();
   if(rs.next()) {
	   System.out.println("Enter the FPath and FName(Destination)");
	   File f=new File(s.nextLine());
	   FileOutputStream fos=new FileOutputStream(f);
	   Blob b=rs.getBlob(2);
	   byte by[]= b.getBytes(1,(int)b.length());
	   fos.write(by);
	   System.out.println("Mfile Retrive Successfully..!!");
	   fos.close();
	   
   }else {
	   System.out.println("Invalid id");
   }
    con.close();
    s.close();
	
	}

}
