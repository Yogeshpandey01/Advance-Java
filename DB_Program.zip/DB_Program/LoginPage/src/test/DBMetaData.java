package test;
import java.sql.*;
public class DBMetaData {

	public static void main(String[] args) throws 
	ClassNotFoundException,SQLException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");	
        System.out.println("--Database Metadata--");
        DatabaseMetaData dmd=con.getMetaData();
        System.out.println("Driver Version:"+dmd.getDriverVersion());
        PreparedStatement ps1=con.prepareStatement("insert into sellproduct20 values(?,?,?,?)");
        ps1.setString(1, "A666");
		ps1.setString(2, "Chicken");
		ps1.setFloat(3,250F);
		ps1.setInt(4, 10);
		int k=ps1.executeUpdate();
		System.out.println("--Parameter Meadata--");
		ParameterMetaData pmd=ps1.getParameterMetaData();
		System.out.println("No of para:"+pmd.getParameterCount());
		if(k>0) {
			System.out.println("Record inserted successfully.!!");
		}
		PreparedStatement ps2=con.prepareStatement("select * from sellproduct20");
		ResultSet rs=ps2.executeQuery();
		System.out.println("--ResultSet Metadata--");
		ResultSetMetaData rsmd=rs.getMetaData();
		System.out.println("colcount:"+rsmd.getColumnCount());
		con.close();
		
	}

}
