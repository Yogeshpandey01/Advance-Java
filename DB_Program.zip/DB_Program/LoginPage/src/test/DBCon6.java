package test;
import java.util.*;
import java.sql.*;
public class DBCon6 {

	public static void main(String[] args) throws ClassNotFoundException,
	SQLException{
	Scanner s=new Scanner(System.in);
	System.out.print("Enter the pCode:");
	String pCode=s.nextLine();
	Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection con=DriverManager.getConnection
    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
    PreparedStatement ps1=con.prepareStatement
    		("Select *from sellproduct20 where pCode=?");
    ps1.setString(1, pCode);
    ResultSet rs=ps1.executeQuery();
    if(rs.next())
    {
    	System.out.println("Old price:"+rs.getFloat(3));	
    	System.out.print("Enter the newPrice:");
    	float newPrice=Float.parseFloat(s.nextLine());
    	PreparedStatement ps2=con.prepareStatement
        		("update sellproduct20 set pPrice=?where pCode=?");
    	ps2.setFloat(1, newPrice);
    	ps2.setString(2, pCode);
    	int k=ps2.executeUpdate();
    	if(k>0) {
    		System.out.println("pPrice update..!!");
    	    }	
    	}
    else {
    	System.out.println("Invalid pCode..!!");
    }
     con.close();
     s.close();
	}

}
