package test;
import java.util.*;
import java.io.*;
import java.sql.*;

public class DBCon12 { 

	public static void main(String[] args)  throws ClassNotFoundException,SQLException,IOException{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the id:");
		String id=s.nextLine();
		System.out.println("Enter the FPath & FName (source)");
		File f=new File(s.nextLine());
		FileReader fr=new FileReader(f);
		Class.forName("oracle.jdbc.driver.OracleDriver");
	    Connection con=DriverManager.getConnection
	    		("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	    PreparedStatement ps=con.prepareStatement
	    		("insert into TextTab20 values(?,?)");
	    ps.setString(1, id);
	    ps.setCharacterStream(2, fr,(int)f.length());
	    int k=ps.executeUpdate();
	    if(k>0) {
System.out.println("file stored successfully");
	    }
       con.close();
       s.close();
	}

}
