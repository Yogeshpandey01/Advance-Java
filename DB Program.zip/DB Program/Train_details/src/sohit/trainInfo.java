package sohit;
import java.sql.*;
public class trainInfo {

	public static void main(String[] args)
	throws ClassNotFoundException
	,SQLException{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:sohit","scott","tiger");
	Statement stm=con.createStatement();
	ResultSet rs=stm.executeQuery("select * from train25");
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getByte(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5));
	}
     con.close();
	}
}
